def is_changed(old_hash, new_hash):
    return old_hash != new_hash
